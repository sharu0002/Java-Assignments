
import javax.swing.*;
import java.awt.*;//container,componant are all in awt
import java.awt.event.*;


public class UIAPP extends JFrame implements ActionListener{
    
    //UI componant
	JButton btn_red, btn_blue, btn_green;

	private Container contentPane;

	UIAPP(String title){
		
		super(title);//this will call the super class of Jframe

		contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());

		btn_red = new JButton("REd");
		btn_red.addActionListener(this);
        btn_blue = new JButton("blue");
        btn_blue.addActionListener(this);
        btn_green = new JButton("green");
        btn_green.addActionListener(this);

        contentPane.add(btn_red);
        contentPane.add(btn_blue);
        contentPane.add(btn_green);

        setSize(500,500);
        setVisible(true);
	}
	
	@Override
	public void actionperformed(ActionEvent e){

		if(e.getSource()== btn_red){
			contentPane.setBackground(Color.red);

		}else if(e.getSource() == btn_blue){
			contentPane.setBackground(Color.blue);

		}else if(e.getSource() == btn_green){
               contentPane.setBackground(Color.green);
		}

	}

	public static void main(String args[]){
		new UIAPP("RGB display windows....");
	}

}