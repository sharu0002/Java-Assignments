import java.util.*;
public class BooksDemo{

public static void main(String[] args)
{
	int copies;
	//Books b1 = new Books();
	//Books b = new Books("let us c","dennis ritchie");
	Sea s = new Sea("let us c","dennis ritchie");
	Scanner obj = new Scanner(System.in);
	//b.Books("let us c","dennis ritchie");
	System.out.println("How many copies you want?");
	copies = obj.nextInt();
	if(copies<=s.stock_position)
		System.out.println("Cost ="+s.price*copies);
	else
		System.out.println("required copies not in stock");

}
}