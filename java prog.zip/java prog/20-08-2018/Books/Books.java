import java.util.*;
import java.io.*;
class Books{
String author,title,publisher;
int price;
int stock_position;

Books()
{
	title="let us c";
	author="dennis ritchie";
	stock_position=3;
	price=980;
	publisher="ABC";
}
}
public class Sea extends Books{
Sea(String t,String a)
{	
	if(this.title.equals(t) && this.author.equals(a))
		search();	
	else {
		notavailable();
	}
}

public void search()
{
	System.out.println("Author: "+author);
	System.out.println("Title: "+title);
	System.out.println("Publisher: "+publisher);
	System.out.println("******************************");
}

public void notavailable()
{
	System.out.println("The book which you are searching for is not available");
	exit();
}

}