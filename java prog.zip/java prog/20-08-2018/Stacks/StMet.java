 import java.util.*;
 class StMet
{
	int st[] = null;
	int top,size;
	//public int MAX=3;
	StMet()
	{
		top=-1;
	}
	public void create()
	{
		System.out.println("Enter size of stack");
		Scanner sc = new Scanner(System.in);
		size = sc.nextInt();
		st=new int[size];
		System.out.println("Array created");
		System.out.println("___________");
	}
	public void push(int e)
	{
		if(top == size-1){
			System.out.println("Stack OverFlow. Cannot Push item :"+ e);
			return;
		}
		else
		{
			top++;
			st[top]=e;
		}
	}                                                                                                                           

	public int pop()
	{
		if(top==-1){		
			System.out.println("stack undeflow");
			return 0;
		}
		else
			return(st[top--]);
	}
	public void display()
	{

		if(top<0)
				System.out.println("No elements in stack");
		else{
			System.out.println("Stack contents are:");
			for(int i=0;i<=top;i++)
				System.out.println(st[i]);
		}
	}
	public void empty()
	{
		st=null;
		System.out.println("Array is empty");
	}

	public static void main(String[] args) {
		StMet s = new StMet();
		s.create();
		System.out.println("Push item 5");
		s.push(5);
		System.out.println("Push item 7");
		s.push(7);
		System.out.println("Push item 8");
		s.push(8);
		System.out.println("__________");
		s.display();
		System.out.println("__________");
		int p = s.pop();
		System.out.println("Item poped is " + p);
		s.display();
		System.out.println("__________");
		s.empty();
	}
}