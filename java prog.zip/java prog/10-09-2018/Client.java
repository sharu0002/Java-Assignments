class Client implements Calculator {

 
 public double subtract(double n1, double n2) {
 	System.out.print("subtract " + n1 + " and " + n2);
 	return n1 - n2;
 }

 public double multiply(double n1, double n2) {
 	System.out.print("multiply " + n1 + " and " + n2);
 	return n1 * n2;
 }

 public double divide(double n1, double n2) {
 	System.out.print("divide " + n1 + " and " + n2);
 	if( n2 !=0){
 		return n1 / n2;
 	}
 	else
 	{
 		System.out.println("\n");
 		System.out.println("Division not possible. Enter a non - zero number");
 		return -1;
 	}
 }
 public double add(double n1, double n2) {
 	System.out.print("add " + n1 + " and " + n2);
 	return n1 + n2;
 }

public static void main(String[] args) {
	double add,sub,mul,div;
	Client c = new Client();
	add = c.add(2.0,3.7);
	System.out.println(" = "+ add);
	System.out.println("__________");
	sub = c.subtract(2.0,3.7);
	System.out.println(" = "+ sub);
	System.out.println("__________");
	div = c.divide(8.0,0.0);
	div = c.divide(6.0,8.0);
	System.out.println(" = "+ div);
	System.out.println("__________");
	
}
 
}