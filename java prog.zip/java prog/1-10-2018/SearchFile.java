//swing component
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFrame;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

//awt component
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


import java.io.*;
import java.lang.Exception;

public class SearchFile extends JFrame implements ActionListener{ //Frame is a super class and ActionListener - processes various actions

    private JMenuBar mnu_bar;
    private JMenu mnu_file;
    private JMenuItem mnu_new, mnu_open, mnu_exit;
    private JTextArea txt_doc;

    
    SearchFile(String title){ //title of the window

        super(title);
        
        Container contentPane = getContentPane(); //Container object. and UI object is added to it

        mnu_bar = new JMenuBar();

        mnu_file = new JMenu("File");

        mnu_new = new JMenuItem("New");
        mnu_new.addActionListener(this); //current class is implementing the action lister. hence "this" refers to current object.
        mnu_open = new JMenuItem("Search");
        mnu_open.addActionListener(this);
        mnu_exit = new JMenuItem("Exit");
        mnu_exit.addActionListener(this);

        mnu_file.add(mnu_new);
        mnu_file.add(mnu_open);
        mnu_file.addSeparator();
        mnu_file.add(mnu_exit);

        mnu_bar.add(mnu_file);

        setJMenuBar(mnu_bar);
        
        txt_doc = new JTextArea();
        contentPane.add(new JScrollPane(txt_doc), BorderLayout.CENTER); //place the text box within JScrollPane

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setSize(900,500);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) //event is handled here
    {
        if(e.getSource() == mnu_new)
        {
            txt_doc.setText(" ");
        }
        else if(e.getSource() == mnu_open)
        {
            JFileChooser fc = new JFileChooser("D:\\");
            fc.showOpenDialog(this);
            File f = fc.getSelectedFile();
            BufferedReader br =null; 
            try{
                br = new BufferedReader(new FileReader(f));
                String msg = br.readLine();
                while(msg!=null)
                {
                    txt_doc.append(msg);
                    txt_doc.append("\n");
                    msg = br.readLine();
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                try{
                if(br!=null)
                    br.close();
                }
                catch(Exception e1)
                {

                }

            }
        }
        else
        {
            System.exit(0);
        }
    }
    public static void main(String[] args) {
        new SearchFile("Search for File......");
    }
}