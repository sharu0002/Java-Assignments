import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.sql.*;

class LoginForm extends JFrame implements ActionListener
{
	DBase db;
	Connection con;
	Statement st;
	ResultSet rs;

	JLabel l_user,l_pass,l_res;
	JTextArea t_user,t_pass;
	JButton submit,reset;
	JPanel p1,p2;
	Container cp = getContentPane();
	String u,p,username,password;

	LoginForm(String name)
	{
		super(name);
		l_user = new JLabel("username");
		l_pass = new JLabel("password");
		

		t_user = new JTextArea();
		t_pass = new JTextArea();
		

		p1 = new JPanel(new GridLayout(2,2));
		p1.add(l_user);
		p1.add(t_user);
		p1.add(l_pass);
		p1.add(t_pass);
		

		submit = new JButton("Submit");
		submit.addActionListener(this);

		reset = new JButton("Reset");
		reset.addActionListener(this);

		p2 = new JPanel(new GridLayout(1,2));
		p2.add(submit);
		p2.add(reset);

		login();

		cp.add(p1,BorderLayout.CENTER);
		cp.add(p2,BorderLayout.SOUTH);

		setSize(500,500);
		setVisible(true);
	}

	public void login()
	{
		try{
			db = new DBase();
			con = db.getConnection();
			st = con.createStatement();
			username = t_user.getText();
			password = t_pass.getText();
			String sql = "select * from login";
			rs = st.executeQuery(sql);
			
		}
		catch(Exception e1)
		{
			System.out.print(e1);
		}
	}

	public void actionPerformed(ActionEvent event)
	{
		if(event.getSource() == submit)
		{
			if((t_user.getText().equals("")) ||(t_pass.getText().equals("")) ){
				JOptionPane.showMessageDialog(this, "Please enter username");
			}

			else
			{
				
				try{
					
						System.out.print("hi...");
						while(rs.next())
						{
							u = rs.getString(1);
							System.out.print(u);
			   	 			p = rs.getString(2);
			   				System.out.print(u);
			
							if(username.equals(u) && password.equals(p))
							{
								JOptionPane.showMessageDialog(this,"Authenticated");
							}
							else{
								JOptionPane.showMessageDialog(this,"Invalid credentials");
							}
						}
					}
					catch(Exception ex)
					{
						System.out.print(ex);
					}
				
			}
		}
		else
		{
			t_user.setText(" ");
			t_pass.setText(" ");
			
		}
	}
	public static void main(String[] args) {
		new LoginForm("Login....");
	}
}