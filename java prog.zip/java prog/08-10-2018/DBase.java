import java.sql.*;
public class DBase
{
	private static Connection con;
	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		String user = "suneha";
		String pass = "suneha";
		String url = "jdbc:mysql://localhost:3306/bookdb";
		con = DriverManager.getConnection(url,user,pass);
		return con;
	}

	public void closeConnection()
	{
		con = null;
	}
}