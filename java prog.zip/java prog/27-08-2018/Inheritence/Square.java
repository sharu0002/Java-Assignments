class Square extends Rectangle
{
	//private double side;

	Square()
	{
		double side = 1.0;
	}
	Square(double side)
	{
		super(side,side);
	}
	Square(String color,boolean filled,double side)
	{
		super();
		length = side;
	}

	public void setSide(double side)
	{
		length = side;
	}
	public double getSide()
	{
		return length;
	}
	public void setWidth(double side)
	{
		length = side;
	}
	public void setLength(double side)
	{
		width = side;
	}
	public double getPerimeter()
	{
		double per = 4 * length;
		return per;
	}
	public double getArea()
	{
		double area = length * width;
		return area;
	}

	public String toString()
	{
		return "A Square with Side : " + length;
	}
}