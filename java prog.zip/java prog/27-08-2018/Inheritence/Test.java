class Test
{
	public static void main(String[] args) {
		Shape s = new Shape();
		Circle c = new Circle();
		Rectangle r = new Rectangle();
		Square sq = new Square();

		c.setRadius(5.0);
		System.out.println(s);
		System.out.println(c);
		System.out.println("Perimeter of Circle is :" + c.getPerimeter());
		System.out.println("Area of Circle is :" + c.getArea());
		System.out.println("********************************");

		r.setWidth(4.0);
		r.setLength(5.0);
		System.out.println(r);
		System.out.println("Perimeter of Rectangle is :" + r.getPerimeter());
		System.out.println("Area of Rectangle is :"+ r.getArea());
		System.out.println("********************************");

		sq.setSide(8.0);
		sq.setLength(7.0);
		sq.setWidth(7.0);
		System.out.println(sq);
		System.out.println("Perimeter of Square is : " + sq.getPerimeter());
		System.out.println("Area of Square is : " + sq.getArea());
	}
}