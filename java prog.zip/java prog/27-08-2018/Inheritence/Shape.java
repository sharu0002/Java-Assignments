public class Shape
{
	private String color = "red";
	private Boolean filled = true;

	Shape()
	{
		color = "green";
		filled = true;
	}

	Shape(String color,Boolean filled)
	{
		this.color = color;
		this.filled = filled;
	}

	public String getColor()
	{

		return this.color;

	}

	public boolean isFilled()
	{
		return this.filled;
	}

	public void setColor(String color)
	{
		this.color = color;
	}
	public void setFilled(Boolean filled)
	{
		this.filled = filled;
	}
	public String toString()
	{
		return "Shape : color = "+ color+"  filled= "+filled;
	}
}