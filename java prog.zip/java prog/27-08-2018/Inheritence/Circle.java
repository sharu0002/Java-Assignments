public class Circle extends Shape
{
	private double radius;

	Circle()
	{
		radius = 1.0;
	}

	Circle(double radius)
	{
		this.radius = radius;
	}

	Circle(String color,boolean filled,double radius)
	{
		super();
		this.radius = radius;
	}

	public double getRadius()
	{
		return this.radius;
	}

	public void setRadius(double radius)
	{
		this.radius = radius;
	}
	public double getArea()
	{
		double area = 3.141 * radius * radius;
		return area;
	}
	public double getPerimeter()
	{
		double per = 2 * 3.141 * radius;
		return per;
	}

	public String toString()
	{
		return "A Circle with radius :" + radius;
	}
}