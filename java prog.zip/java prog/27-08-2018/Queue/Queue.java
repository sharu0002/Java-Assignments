import java.util.Scanner;
import java.lang.*; 
public class Queue{
	private int front,rear,size;
	int Q[] = null;
	Queue()
	{
		front=-1;
		rear=-1;
	}

	public void createNew(int size)
	{
		this.size = size;
		System.out.println("Queue Size is : " + size);
		Q = new int[size];
	}

	public void add(int item)
	{	
		if(rear < size -1){
			Q[++rear]= item;
			
		}

		else{
			System.out.println("Queue overflow. cannot insert elements");
			return;
		}
			
	}

	public int remove()
	{
		if(front == rear){
			front = rear = -1;
			return -1;
		}
		else
		{	
			return Q[++front];
		}

	}

	public void display()
	{
		for(int i=front+1;i<=rear;i++)
		{
			System.out.println(Q[i]);
		}
	}

	public static void main(String[] args)
	{
		int el,i,item;
		Scanner sc = new Scanner(System.in);
		Queue q = new Queue();
		q.createNew(2);
		q.add(5);
		System.out.println("Item 5 inserted");
		q.add(19);
		System.out.println("Item 19 inserted");
		q.add(30);
		System.out.println("Queue elements are:");
		q.display();

		System.out.println("**********");
		el=q.remove();
		if(el==-1)
			System.exit(0);
		else
			System.out.println("Deleted item is " +el);
		el=q.remove();
		if(el==-1)
			System.exit(0);
		else
			System.out.println("Deleted item is "+el);

		el=q.remove();
		if(el==-1){
			System.out.println("Cannot delete, Queue Underflow");
			System.exit(0);
		}
		else
			System.out.println("Deleted item is "+el);
		
	}

}
