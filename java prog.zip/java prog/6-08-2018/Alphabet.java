import java.util.*;
public class Alphabet{
	public static void main(String[] args)
	{
		Scanner ip = new Scanner(System.in);
		String str;
		char c[] = new char[20];
		char temp;
		System.out.println("Enter a String");
		str=ip.nextLine();
		int length = str.length();
		System.out.println("Length of a String is: "+ length);
		
		for(int i=0;i<length;i++)
		{
			c[i]=str.charAt(i);
		}
		for(int i=0;i<length-1;i++)
		{
			for(int j=0;j<length-i-1;j++)
			{
				if(c[j]>c[j+1])
				{
					temp=c[j];
					c[j]=c[j+1];
					c[j+1]=temp;
				}
			}
		}
		System.out.println("Alphabetic Order");
		for(int k=0;k<length;k++)
			System.out.println(c[k]);


	}
}