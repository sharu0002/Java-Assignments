public class Sum{
	public static void main(String[] args)
	{
		if(args.length<3){
			System.out.println("Usage: <command><filename><args1><args2><args3>");
			return;
		}
		else{
			int sum = Integer.parseInt(args[0])+Integer.parseInt(args[1])+Integer.parseInt(args[2]);
			System.out.println("Sum is :"+sum);
		}

	}
}