import java.util.*;
public class Vowels{
	public static void main(String[] args)
	{
		//char v[] = {'A','E','I','O','U'};
		String str;
		int count=0;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a String");
		str = input.nextLine();
		int l = str.length();
		for (int i = 0; i < l; i++)
        {
            if (str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i'
                    || str.charAt(i) == 'o' || str.charAt(i) == 'u')
            {
                count++;
            }
        }
		 System.out.println("Count of Vowels:" + count);
	}
}