 import java.util.*;
public class Palindrome{
	
	public static void main(String[] args){
		int i;
		String str = new String();
		Scanner ip= new Scanner(System.in);
		System.out.println("Enter a String");
		str=ip.nextLine();
		int l=str.length();
		System.out.println(l);
		System.out.println("Checking for Palindrome");
		for(i=0;i<l;i++)
			{
				if(str.charAt(i)!=str.charAt(l-i-1))
					{
						System.out.println("Not a Palindrome");
						return;
					}
				
			}
		System.out.println("String is a palindrome");
			
	}

}
