/* My First Java Program*/ 
public class HelloWorld{
	public static void main(String[] args){
        /*prints on the screen*/
		System.out.println("Hello World");
	}
}