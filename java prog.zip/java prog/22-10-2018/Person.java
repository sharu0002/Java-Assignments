import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

public class Person extends JFrame implements ActionListener
{

	DBase db;
	Connection con;
	Statement st;
	ResultSet rs;

	Container contentPane;
	JPanel panel1,panel2;
	JLabel l_first,l_last,l_age,l_address;
	JTextField t_first,t_last,t_age,t_address;
	JButton previous,next,first,last;


	Person(String title)
	{
		super(title);
		contentPane = getContentPane();
		l_first = new JLabel("First Name:");
		l_last = new JLabel("Last Name:");
		l_age = new JLabel("Age:");
		l_address = new JLabel("Address:");


		t_first = new JTextField();
		t_last = new JTextField();
		t_age = new JTextField();
		t_address = new JTextField();

		panel1 = new JPanel();
		panel1.setLayout(new GridLayout(4,2));

		panel1.add(l_first);
		panel1.add(t_first);

		panel1.add(l_last);
		panel1.add(t_last);

		panel1.add(l_age);
		panel1.add(t_age);

		panel1.add(l_address);
		panel1.add(t_address);

		panel2 = new JPanel();
		panel2.setLayout(new GridLayout(1,4));

		previous = new JButton("Previous");
		previous.addActionListener(this);

		next = new JButton("Next");
		next.addActionListener(this);

		first = new JButton("First");
		first.addActionListener(this);

		last = new JButton("Last");
		last.addActionListener(this);

		panel2.add(first);
		panel2.add(previous);
		panel2.add(next);
		panel2.add(last);
		
		contentPane.add(panel1, BorderLayout.CENTER);
		contentPane.add(panel2, BorderLayout.SOUTH);
		
		callQuery();

		setSize(500,500);
		setVisible(true);
		callQuery();
	}

	public void callQuery()
	{
		try{
					
					db = new DBase();
					con = db.getConnection();
					st = con.createStatement();
					String qry = "select * from person";
					rs = st.executeQuery(qry);
		}
		catch(Exception exp)
		{
			System.out.print(exp);
		}
	}
	
	public void actionPerformed(ActionEvent event)
	{
		Object source = event.getSource();
		if(source == previous)
		{
			try{

					System.out.println("previous....");
					if(rs!=null){
							
							
							if(rs.isFirst()){
								JOptionPane.showMessageDialog(this,"First record.....");
							}
							else{
								rs.previous();
								t_first.setText(String.valueOf(rs.getString(1)));
								t_last.setText(String.valueOf(rs.getString(2) + "\t"));
								t_age.setText(String.valueOf(rs.getInt(3) + "\t"));
								t_address.setText(String.valueOf(rs.getString(4) + "\t"));
							}
						}
							
					}
				catch(Exception exp){
					System.out.print(exp);
				}
		}

		else if(source == first)
		{
			try{

					if(rs!=null){
							    rs.first();
								t_first.setText(String.valueOf(rs.getString(1)));
								t_last.setText(String.valueOf(rs.getString(2) + "\t"));
								t_age.setText(String.valueOf(rs.getInt(3) + "\t"));
								t_address.setText(String.valueOf(rs.getString(4) + "\t"));
							}
					else
						{
									JOptionPane.showMessageDialog(this,"No record found....");
						}
				   }
			catch(Exception exp)
			{
					System.out.println(exp);
			}
		}
		else if(source == next)
		{
			try{
					
					if(rs!=null){
							
							if(rs.isLast()){
								JOptionPane.showMessageDialog(this,"Last record.....");
							}
							else{
								rs.next();
									t_first.setText(String.valueOf(rs.getString(1)));
									t_last.setText(String.valueOf(rs.getString(2) + "\t"));
									t_age.setText(String.valueOf(rs.getInt(3) + "\t"));
									t_address.setText(String.valueOf(rs.getString(4) + "\t"));
							}
							
						}
				}catch(Exception exp){
					System.out.print(exp);
				}
		}

	else
			{
				try
				{

					if(rs!=null){
							
							rs.last();
							t_first.setText(String.valueOf(rs.getString(1)));
							t_last.setText(String.valueOf(rs.getString(2) + "\t"));
							t_age.setText(String.valueOf(rs.getInt(3) + "\t"));
							t_address.setText(String.valueOf(rs.getString(4) + "\t"));
							}
							else{
									JOptionPane.showMessageDialog(this,"No record found...");
								
							}
							
				}catch(Exception exp){
						System.out.print(exp);
				
			}
	}
}


	public static void main(String[] args) {
		
				new Person("View Records....");
	}
}
