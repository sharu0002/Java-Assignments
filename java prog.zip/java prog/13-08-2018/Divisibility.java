public class Divisibility{
	public static void main(String[] args)
	{
		int sum=0,i,count=0;
		int a[];
		a = new int[100];
		System.out.println("Integers greater than 100 and less than 200 divisible by 7 are: ");
		for(i=101;i<200;i++)
		{
			if(i%7==0){
				System.out.println(i);
				count=count+1;
				sum=sum+i;
			}
		}
		System.out.println("Count is:"+count);
		System.out.println("Sum is:"+sum);
		
	}
}