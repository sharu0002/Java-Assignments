import java.util.*;
public class Temp{
	public static void main(String[] args)
	{
		Scanner ip = new Scanner(System.in);
		double c,f;
		System.out.println("Enter Temperature in Fahrenheit");
		f = ip.nextInt();
		c = calculate(f);
		System.out.println("Temperature in Celsius is:" + c);

	}

	static double calculate(double fa)
	{
		double c=(fa-32)/1.8;
		return c;
		
	}

}