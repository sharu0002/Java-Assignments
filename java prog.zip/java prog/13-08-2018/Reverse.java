import java.util.*;
public class Reverse{
	public static void main(String[] args)
	{
		Scanner ip = new Scanner(System.in);
		int num,rev=0;
		System.out.println("Enter a number");
		num = ip.nextInt();
		while(num !=0)
		{
			rev=(rev*10)+num%10;
			num=num/10
		}

		System.out.println("Reversed String is:"+rev);
	}
}