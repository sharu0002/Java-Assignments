import java.util.*;
public class MaxMin{

	public static void main(String[] args)
	{
		int n,i,max,min;
		int a[];
		a = new int[11];
		Scanner ip = new Scanner(System.in);
		System.out.println("Enter n");
		n = ip.nextInt();
		System.out.println("Enter Array Contents\n");
		for(i=0;i<n;i++)
			a[i] = ip.nextInt();

		max=find_max(n,a);
		min=find_min(n,a);
		System.out.println("Maximum element is:"+a[max]);
		System.out.println("Minimum element is:"+a[min]);
		sort(n,a);

	}

	static int find_max(int len, int array[])
	{
		int j,max,el=0;
		max=array[0];
		for(j=1;j<len;j++){
			if(array[j]>max)
			{
				max=array[j];
				el=j;
			}
		}
		return el;
	}

	static int find_min(int len, int array[])
	{
		int j,min,el=0;
		min=array[0];
		for(j=1;j<len;j++){
			if(array[j]<min)
			{
				min=array[j];
				el=j;
			}
		}
		return el;
	}

	static void sort(int len,int array[])
	{
		int i,j,temp=0;
		System.out.println("Sorting the array");
		for(i=0;i<len-1;i++)
		{
			for(j=0;j<len-i-1;j++)
			{
				if(array[j]>array[j+1])
				{
					temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}
		System.out.println("Sorted Array is:");
		for(i=0;i<len;i++)
			System.out.println(array[i]);
	}
}
