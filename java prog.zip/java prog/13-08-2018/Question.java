import java.util.*;
import java.lang.*;
public class Question{
	public static void main(String[] args)
	{
		Scanner ip = new Scanner(System.in);
		int choice,i;
		System.out.println("Who is the CEO of Google");
		System.out.println("1.Sathya Nadella  2.Narayana Murthy 3.Mukesh Ambani  4.Sundar Pichai");
		for(i=0;i<3;i++){
			System.out.println("Enter your choice");
			choice = ip.nextInt();
			switch(choice)
			{
			case 1: System.out.println("Try Again!");
					break;
			case 2: System.out.println("Try Again!");
					break;
			case 3: System.out.println("Try Again!");
					break;
			case 4: System.out.println("Good!");
					System.exit(0);	
			}
		}
		System.out.println("Correct Answer is option 4");
		
	}
}