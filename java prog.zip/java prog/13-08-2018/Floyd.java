import java.util.*;
public class Floyd{
	public static void main(String[] args)
	{
		int i,j,n=1;
		Scanner ip = new Scanner(System.in);
		System.out.println("Enter the number of lines");
		int l=ip.nextInt();
		for(i=1;i<=l;i++)
		{
			for(j=1;j<=i;j++)
			{
				System.out.print(n + "\t" );
				n++;
			}
			System.out.println();
		}
	}
}