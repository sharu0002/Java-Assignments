import java.util.*;
public class FloydModified{
	public static void main(String[] args)
	{
		int i,j,l,n=1;
		Scanner ip=new Scanner(System.in);
		System.out.println("Enter number of lines\n");
		l=ip.nextInt();
		System.out.println("Pattern:");
		for(i=1;i<=l;i++)
		{
			for(j=0;j<=i;j++)
			{
				System.out.print(j%2+"\t");
			}
			System.out.println();
		}
	}
